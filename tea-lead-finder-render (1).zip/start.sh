#!/bin/bash
set -e
python3 tea_lead_finder.py
